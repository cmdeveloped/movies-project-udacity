Hello! My name is Collin, and this is my movie trailer project.

I'm new to Python, but not to OOP. I'm excited to have completed my first project
with Udacity, and can't wait to continue.

To view my project, you'll have to extract all files from the compressed .zip file.

1. Open file entertainment_center.py to run in Idle
2. Click Run in the toolbar, and Run Module
	or Hit F5
3. Wait for the program to open up a new tab in default browser. 
4. Check out the application!